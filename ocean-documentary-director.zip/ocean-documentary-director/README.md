# Ocean Documentary Director

A lightweight Claude Code skill for planning original cinematic 2D ocean documentaries.

Install: copy `SKILL.md` to `.claude/skills/ocean-documentary-director/SKILL.md`.

Example: “Use ocean-documentary-director to plan a sourced 10-minute video about cookiecutter sharks.”

Instruction-only. It does not bundle video analysis, sources, or animation software.
