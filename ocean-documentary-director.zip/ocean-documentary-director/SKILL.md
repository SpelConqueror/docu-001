---
name: ocean-documentary-director
description: Plan original, fact-checked cinematic 2D ocean documentaries with hooks, scripts, shot lists, narration, and thumbnails.
---

# Ocean Documentary Director

When given a topic:
1. Verify incidents, dates, species facts, habitat, diet, human risk, and conservation status with trustworthy sources. Mark unknowns clearly.
2. Write an original opening hook, coherent documentary story, natural voiceover, and source list. Never invent danger or scientific claims.
3. Plan timed shots with camera movement, layered 2D/2.5D visuals, lighting, sound, and motion-graphics cues.
4. Propose a clear title and original thumbnail concept without misleading images or claims.
5. Check accuracy, pacing, anatomy, audio, licensing, and visual continuity before delivery.

Use Remotion for production when authorized. Show a preview for user approval before continuing. Never copy another channel's scripts, graphics, footage, or voice. Do not claim a video was produced or audited without evidence.
